<?php
/**
 * Index file
 *
 * @package     Blogsy
 * @author      Peregrine Themes
 * @since       1.0.0
 */

/* Silence is golden, and we agree. */
