<?php
/**
 * Template part for displaying blog index
 *
 * @package Blogsy
 */

get_template_part( 'archive' );
