<?php
/**
 * Template part for displaying search result
 *
 * @package Blogsy
 */

get_template_part( 'archive' );
