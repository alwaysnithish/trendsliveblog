;(function ($) {

	"use strict";

	wp.customize.controlConstructor['blogsy-alignment'] = wp.customize.Control.extend(
		{

			ready: function () {

				'use strict';

				var control = this;
			},

		}
	);

})( jQuery );
