<?php
/**
 * Blogsy Customizer custom text control class.
 *
 * @package     Blogsy
 * @author      Peregrine Themes
 * @since       1.0.0
 */

/**
 * Do not allow direct script access.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Blogsy_Customizer_Control_Number' ) ) :
	/**
	 * Blogsy Customizer custom select control class.
	 */
	class Blogsy_Customizer_Control_Number extends Blogsy_Customizer_Control {

		/**
		 * The control type.
		 *
		 * @var string
		 */
		public $type = 'blogsy-number';

		/**
		 * Placeholder text.
		 *
		 * @since 1.0.0
		 * @var string|false
		 */
		public $placeholder = '';

		public $info;

		/**
		 * Minimum range value.
		 *
		 * @since 1.0.0
		 * @var integer
		 */
		public $min = 0;

		/**
		 * Maximum range value.
		 *
		 * @since 1.0.0
		 * @var integer
		 */
		public $max = 1000;

		/**
		 * Range step value.
		 *
		 * @since 1.0.0
		 * @var integer
		 */
		public $step = 1;

		/**
		 * Enqueue control related scripts/styles.
		 *
		 * @access public
		 */
		public function enqueue() {
		}

		/**
		 * Refresh the parameters passed to the JavaScript via JSON.
		 *
		 * @see WP_Customize_Control::to_json()
		 */
		public function to_json() {
			parent::to_json();
			$this->json['placeholder'] = $this->placeholder;
			$this->json['info']        = $this->info;
			$this->json['min']         = $this->min;
			$this->json['max']         = $this->max;
			$this->json['step']        = $this->step;
		}

		/**
		 * An Underscore (JS) template for this control's content (but not its container).
		 *
		 * Class variables for this control class are available in the `data` JS object;
		 * export custom variables by overriding {@see WP_Customize_Control::to_json()}.
		 *
		 * @see WP_Customize_Control::print_template()
		 */
		protected function content_template() {
			?>
			<div class="blogsy-control-wrapper blogsy-text-wrapper">

				<label>
					<# if ( data.label ) { #>
						<div class="customize-control-title">
							<span>{{{ data.label }}}</span>

							<# if ( data.description ) { #>
								<i class="blogsy-info-icon">
									<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-help-circle">
										<circle cx="12" cy="12" r="10"></circle>
										<path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
										<line x1="12" y1="17" x2="12" y2="17"></line>
									</svg>
									<span class="blogsy-tooltip">{{{ data.description }}}</span>
								</i>
							<# } #>

						</div>
					<# } #>

					<input type="number" value="{{ data.value }}" placeholder="{{ data.placeholder }}" {{{ data.link }}} min="{{ data.min }}"
								max="{{ data.max }}"
								step="{{ data.step }}"/>
					<div class="blogsy-info-text">{{{ data.info }}}</div>
				</label>

			</div><!-- END .blogsy-control-wrapper -->
			<?php
		}
	}
endif;
